<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GYMORT - Fitness And GYM</title>
    <?php include_once("assets/includes/links.php");?>
</head>
<body>
    
    <div class="site_content">
        
            <?php include_once("assets/includes/header.php");?>
        <!-- Banner-Slider Start -->
        <section id="hero_sec">
            <div class="home_banner_slider" id="home_banner_1">
                <div class="banner_slider_list lazy">
                    <div class="banner_slider_item">
                        <div class="banner_slider_img slide slide_one" data-animation-in="shine_1" data-delay-in="0.2">
                             <div class="slider_overlay"></div>
                            <div class="container">
                                <div class="banner_slider_content">
                                    <h1 class="d-none">hidden</h1>
                                    <h2 class="d-none">hidden</h2>
                                    <h3 class="d-none">hidden</h3>
                                    <h4 class="d-none">hidden</h4>
                                    <h5 class="line_height_normal fw_500 color_white satoshi_fontfamily" data-animation-in="fadeInRight" data-delay-in="0.2">Fitness for Everyone</h5>
                                    <h1 data-animation-in="fadeInRight" data-delay-in="0.2">NO MATTER YOUR FITNESS LEVEL.</h1>
                                    <h2 class="d-none">hidden</h2>
                                    <h3 class="d-none">hidden</h3>
                                    <h4 class="d-none">hidden</h4>
                                    <div class="slider_button"  data-animation-in="fadeInRight" data-delay-in="0.2">
                                        <div class="banner_btn">
                                            <a href="#our_contactus_page" class="orange_btn">
                                                <span class="orenge_text orangeglow_btn" data-hover="Get Started">
                                                    Get Started
                                                </span>
                                                <span class="orenge_icon whiteglow_btn">
                                                    <img src="assets/images/svgs/common_button_arrow1.webp" alt="common_button_arrow">
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="banner_slider_item">
                        <div class="banner_slider_img slide slide_two" data-animation-in="shine_1" data-delay-in="0.2">
                            <div class="shine"></div>
                            <div class="slider_overlay"></div>
                            <div class="container">
                                <div class="banner_slider_content">
                                    <h5 class="line_height_normal fw_500 color_white satoshi_fontfamily" data-animation-in="fadeInRight" data-delay-in="0.2">GIVE YOUR BODY THE BEST FORM</h5>
                                    <h1 data-animation-in="fadeInRight" data-delay-in="0.2">SHAPING YOUR MUSCLES</h1>
                                    <h2 class="d-none">hidden</h2>
                                    <h3 class="d-none">hidden</h3>
                                    <h4 class="d-none">hidden</h4>
                                    <h5 class="d-none">hidden</h5>
                                    <div class="slider_button"  data-animation-in="fadeInRight" data-delay-in="0.2">
                                        <div class="banner_btn">
                                            <a href="#our_contactus_page" class="orange_btn">
                                                <span class="orenge_text orangeglow_btn" data-hover="Get Started">
                                                    Get Started
                                                </span>
                                                <span class="orenge_icon whiteglow_btn">
                                                    <img src="assets/images/svgs/common_button_arrow1.webp" alt="common_button_arrow">
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="quick_contact">
                    <a href="tel:+052 834 6663" class="color_white custom_cursor_orangeglow">
                        <span>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <mask style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24">
                                <path d="M0 0H24V24H0V0Z" fill="white"/>
                                </mask>
                                <g>
                                <path d="M5 4H9L11 9L8.5 10.5C9.57096 12.6715 11.3285 14.429 13.5 15.5L15 13L20 15V19C20 19.5304 19.7893 20.0391 19.4142 20.4142C19.0391 20.7893 18.5304 21 18 21C14.0993 20.763 10.4202 19.1065 7.65683 16.3432C4.8935 13.5798 3.23705 9.90074 3 6C3 5.46957 3.21071 4.96086 3.58579 4.58579C3.96086 4.21071 4.46957 4 5 4Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M15 7C15.5304 7 16.0391 7.21071 16.4142 7.58579C16.7893 7.96086 17 8.46957 17 9" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M15 3C16.5913 3 18.1174 3.63214 19.2426 4.75736C20.3679 5.88258 21 7.4087 21 9" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </g>
                            </svg>                                
                        </span>
                        <h6 class="line_height_24 fw_500 satoshi_fontfamily color_white">
                           052 834 6663
                        </h6>
                    </a>
                </div>
            </div>
        </section>
        <!-- Banner-Slider End -->

       <!-- About-Us Start -->
        <section class="about_us_sec" id="about">
            <div class="container">
                <div class="about_us sec_padding">
                    <div class="row">
                        <div class="col-xl-5 col-lg-6">
                            <div class="about_big_img_area h-100 text-lg-start text-center">
                                <div class="about_big_img about_img_shap_1 reveal h-100">
                                    <img src="assets/images/about-us/vertical-1.webp" alt="about_img" class="h-100">
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-7 col-lg-6">
                            <div class="about_detail_area">
                                <div class="common_title_area about_us_title text-md-start text-center">
                                    <h5 class="satoshi_fontfamily fw_500 line_height_normal color_orange reveal custom_fade_top">Know About Us</h5>
                                    <h3 class="pt-10 reveal custom_lightSpeedInLeft">PERSONAL TRAININGS ANYWHERE</h3>
                                    <h4 class="d-none">hidden</h4>
                                    <h5 class="d-none">hidden</h5>
                                </div>
                                <div class="about_img_detail_area">
                                    <div class="row">
                                        <div class="col-xl-7 col-lg-12 col-sm-7">
                                            <div class="about_img_inner_info">
                                                <p class="satoshi_fontfamily fw_500 line_height_30 color_lightblack" data-aos="fade-down">
                                                    Welcome to Gym63, where we believe that fitness is for everyone! Whether you're a seasoned athlete or just starting your fitness journey, our gym offers a supportive and inclusive environment for people of all fitness levels.
                                                </p>
                                                <ul class="satoshi_fontfamily fw_500">
                                                    <li class="reveal custom_lightSpeedInLeft">We find your trainer.</li>
                                                    <li class="reveal custom_lightSpeedInLeft">We make your plan.</li>
                                                    <li class="reveal custom_lightSpeedInLeft">Take training anywhere.</li>
                                                </ul>
                                                <div class="about_us_btn reveal custom_fade_buttom">
                                                    <a href="#" class="orange_btn black_btn">
                                                        <span class="orenge_text whiteglow_btn" data-hover="Read More">
                                                            Read More
                                                        </span>
                                                        <span class="orenge_icon whiteglow_btn">
                                                            <img src="assets/images/svgs/common_button_arrow1.webp" alt="common_button_arrow">
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-5">
                                            <div class="about_img_inner about_img_shap_2 reveal d-xl-block d-lg-none d-sm-block d-none">
                                                <img src="assets/images/about-us/vertical-2.webp" alt="about_img" class="h-100">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About-Us End -->



        <!-- Our-Trainings Start -->
        <section class="our_training_sec" id="services">
            <div class="bg_black">
                <div class="container">
                    <div class="our_training sec_padding">
                        <div class="row">
                            <div class="col-xl-4">
                                <div class="common_title_area our_training_title text-xl-start text-center">
                                    <h5 class="satoshi_fontfamily fw_500 line_height_normal color_orange reveal custom_fade_top">Our Trainings</h5>
                                    <h3 class="pt-10 pb-40 reveal custom_lightSpeedInLeft color_white">MEET OUR BEST PROGRAM FOR YOUR BEST RESULTS</h3>
                                    <h4 class="d-none">hidden</h4>
                                    <h5 class="d-none">hidden</h5>
                                    <div class="our_training_btn reveal custom_fade_buttom">
                                        <div class="banner_btn">
                                            <a href="#" class="orange_btn">
                                                <span class="orenge_text orangeglow_btn" data-hover="Get Started">
                                                    Get Started
                                                </span>
                                                <span class="orenge_icon whiteglow_btn">
                                                    <img src="assets/images/svgs/common_button_arrow1.webp" alt="common_button_arrow">
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-8 col-12">
                                <div class="our_training_image_area">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="our_training_image_list">
                                                <div class="our_training_image_box">
                                                    <a href="#" class="d-block our_traning_btn_box">
                                                        <div class="our_trining_img our_trining_img_shap reveal">
                                                            <img src="assets/images/training/cardio.webp" alt="our_trining">
                                                        </div>
                                                        <h5 class="color_white mt-10">CARDIO TRAINING</h5>
                                                    </a>
                                                </div>
                                                <div class="our_training_image_box">
                                                    <a href="#" class="d-block our_traning_btn_box">
                                                        <div class="our_trining_img our_trining_img_shap reveal">
                                                            <img src="assets/images/training/outdoor.webp" alt="our_trining">
                                                        </div>
                                                        <h5 class="color_white mt-10">OUTDOOR TRAINING</h5>
                                                    </a>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="our_training_image_list">
                                                <div class="our_training_image_box">
                                                    <a href="#" class="d-block our_traning_btn_box">
                                                        <div class="our_trining_img our_trining_img_shap reveal">
                                                            <img src="assets/images/training/cross.webp" alt="our_trining">
                                                        </div>
                                                        <h5 class="color_white mt-10">CROSSFIT TRAINING</h5>
                                                    </a>
                                                </div>
                                                <div class="our_training_image_box">
                                                    <a href="#" class="d-block our_traning_btn_box">
                                                        <div class="our_trining_img our_trining_img_shap reveal">
                                                            <img src="assets/images/training/power.webp" alt="our_trining">
                                                        </div>
                                                        <h5 class="color_white mt-10">POWER LIFTING TRAINING</h5>
                                                    </a>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Our-tranings End -->

        

       

        <!-- Traning-Video Start -->
        <div class="traning_video_sec">
            <div class="container-fluid p-0">
                <div class="row m-0">
                    <div class="col-12 p-0">
                        <div class="traning_videoplayer" data-aos="fade-zoom-in" data-aos-easing="ease-in-back" data-aos-offset="0">
                            <a href="javascript:void(0);" data-url="https://www.youtube.com/embed/bVce0qSREK8?rel=0&amp;showinfo=0&amp;autoplay=1" class="js-overlay-start start">
                                <span class="video_text_area orangeglow_btn">
                                    <svg width="160" height="160" viewBox="0 0 160 160" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="35" cy="21" r="3" fill="#FF640D"/>
                                        <circle cx="153" cy="71" r="3" fill="#FF640D"/>
                                        <circle cx="51" cy="148" r="3" fill="#FF640D"/>
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M80.8187 0.307129L74.8335 11.7697L77.6991 11.9357L78.9631 9.5149L85.6659 9.90309L86.6416 12.4536L89.5072 12.6195L84.8865 0.542712L80.8187 0.307129ZM84.8347 7.70782L80.0423 7.43027L82.6263 2.47636L82.8404 2.48876L84.8347 7.70782ZM61.6695 14.3507L59.6371 2.73756L62.237 2.28298L63.8999 11.7846L72.3984 10.2987L72.768 12.4102L61.6695 14.3507ZM40.9965 10.1121L45.6722 20.9356L48.0954 19.8898L46.3755 15.9085L53.0241 13.0391C54.1448 12.5554 54.8911 11.898 55.2628 11.0671C55.6447 10.2318 55.5871 9.23886 55.0901 8.08839C54.5931 6.93791 53.9095 6.21519 53.0394 5.92022C52.1794 5.62089 51.189 5.71307 50.0683 6.19676L40.9965 10.1121ZM44.2698 11.0342L50.6307 8.28887C51.0749 8.09714 51.4611 8.06217 51.7892 8.18396C52.1231 8.29131 52.4056 8.61242 52.6366 9.14729C52.8633 9.67206 52.9035 10.0978 52.7571 10.4244C52.6208 10.7466 52.3305 11.0036 51.8862 11.1953L45.5189 13.9255L44.2698 11.0342ZM22.4105 43.1732L12.5031 36.6414L14.1923 34.6143L21.4317 39.3754L21.5934 35.2396L16.9162 31.3456L18.6055 29.3185L23.2953 33.2231L27.3019 32.3313L21.3189 26.0624L23.0081 24.0353L31.2263 32.5943L29.8116 34.292L23.921 35.4608L23.8252 41.4755L22.4105 43.1732ZM13.4374 59.3114C14.8189 58.6586 15.9331 57.3716 16.7802 55.4503L18.0574 52.5533C18.9133 50.6119 19.1162 48.9114 18.666 47.4518C18.2058 45.9878 17.07 44.8568 15.2585 44.0589C13.4571 43.2654 11.8657 43.1951 10.4842 43.8479C9.09269 44.4963 7.95788 45.8164 7.07979 47.8081L5.88239 50.524C5.00429 52.5157 4.79535 54.2436 5.25556 55.7076C5.7057 57.1672 6.83148 58.2937 8.6329 59.0872C10.4444 59.8851 12.0459 59.9598 13.4374 59.3114ZM7.37098 54.0987C7.24339 53.2978 7.42573 52.339 7.91799 51.2224L8.96905 48.8384C9.46131 47.7219 10.0462 46.9404 10.7237 46.4941C11.4012 46.0477 12.2132 45.9369 13.1597 46.1616L8.76925 56.1201C7.96466 55.5735 7.49857 54.8997 7.37098 54.0987ZM15.9885 51.9303L14.9574 54.269C14.4519 55.4158 13.8603 56.2123 13.1828 56.6587C12.5053 57.105 11.6883 57.2136 10.7317 56.9845L15.1222 47.026C15.9368 47.577 16.4079 48.253 16.5355 49.054C16.6676 49.8449 16.4852 50.8037 15.9885 51.9303ZM11.6753 78.665L0 76.9905L0.37957 74.3464L9.95832 67.2914L1.56514 66.0877L1.94002 63.4762L13.6154 65.1507L13.2358 67.7948L3.64071 74.8474L12.0502 76.0535L11.6753 78.665ZM148.295 80.4615L160 81.9116L158.785 91.7134C158.634 92.9243 158.212 93.8246 157.519 94.4143C156.824 95.015 155.854 95.2382 154.61 95.0841C153.366 94.9299 152.48 94.4768 151.953 93.7247C151.424 92.9836 151.235 92.0075 151.385 90.7966L152.276 83.6131L147.97 83.0797L148.295 80.4615ZM156.695 91.1388L157.547 84.2661L154.42 83.8788L153.552 90.7494C153.492 91.2294 153.567 91.6097 153.776 91.8904C153.983 92.1819 154.371 92.3629 154.939 92.4332C155.517 92.5048 155.937 92.424 156.199 92.1905C156.47 91.9694 156.635 91.6188 156.695 91.1388ZM145.915 97.3548L156.973 101.455L156.055 103.929L147.007 100.574L144.007 108.659L141.996 107.914L145.915 97.3548ZM148.391 120.901L141.491 109.965L139.906 112.357L141.363 114.666L137.655 120.261L134.959 119.821L133.374 122.213L146.141 124.297L148.391 120.901ZM139.972 120.647L142.623 116.647L145.606 121.371L145.488 121.55L139.972 120.647ZM127.577 128.374L130.396 131.495L140.122 132.936L137.698 135.124L130.92 134.043L131.32 140.881L128.895 143.07L128.436 133.286L125.606 130.154L127.577 128.374ZM117.216 150.849L112.866 139.891L110.413 140.864L113.546 148.757L102.654 143.941L100.17 144.926L104.52 155.884L106.973 154.911L103.846 147.034L114.732 151.834L117.216 150.849ZM90.304 146.965C92.3923 146.738 94.0644 147.06 95.3202 147.93C96.5773 148.812 97.3124 150.236 97.5257 152.203C97.7377 154.159 97.3237 155.697 96.2835 156.815C95.2444 157.945 93.6425 158.627 91.4777 158.862L88.5256 159.181C86.3607 159.416 84.6498 159.093 83.3928 158.212C82.1369 157.341 81.403 155.928 81.1909 153.972C80.9776 152.005 81.3905 150.456 82.4296 149.327C83.4698 148.208 85.045 147.534 87.1551 147.306L90.304 146.965ZM91.0662 156.75C92.2798 156.619 93.2019 156.298 93.8324 155.787C94.4629 155.277 94.8141 154.536 94.8859 153.567L84.0617 154.739C84.3397 155.671 84.8413 156.319 85.5666 156.682C86.2919 157.046 87.2613 157.162 88.475 157.031L91.0662 156.75ZM90.1906 149.133L87.6486 149.408C86.424 149.541 85.502 149.862 84.8824 150.371C84.2519 150.882 83.9013 151.627 83.8306 152.608L94.6549 151.436C94.3757 150.493 93.8735 149.84 93.1482 149.476C92.4229 149.112 91.4371 148.998 90.1906 149.133ZM75.6096 160L76.342 148.16L74.1646 147.779L68.8987 150.691L64.951 146.168L62.7736 145.787L59.4412 157.173L62.0412 157.628L64.4999 149.32L67.269 152.348L66.2173 158.358L68.8173 158.812L69.8661 152.819L73.5347 150.899L73.0097 159.545L75.6096 160ZM45.6484 138.952L38.5715 148.383L30.6664 142.457C29.6898 141.725 29.118 140.912 28.9508 140.017C28.7748 139.116 29.063 138.164 29.8152 137.161C30.5674 136.159 31.401 135.616 32.316 135.532C33.2222 135.442 34.1636 135.763 35.1402 136.495L40.9338 140.838L43.5369 137.369L45.6484 138.952ZM32.2039 140.93L37.7467 145.086L39.6372 142.566L34.1043 138.398C33.7171 138.108 33.3498 137.983 33.0023 138.025C32.646 138.06 32.2962 138.307 31.9531 138.764C31.6034 139.23 31.4648 139.634 31.5374 139.977C31.5946 140.323 31.8168 140.64 32.2039 140.93ZM23.1605 136.054L32.1957 128.476L24.9532 119.849L23.3105 121.227L28.8563 127.833L21.4638 134.033L23.1605 136.054ZM23.4202 118.387L10.4968 118.955L8.66203 115.319L16.8015 105.269L18.094 107.831L16.375 109.953L19.3984 115.945L22.1276 115.825L23.4202 118.387ZM17.0527 116.057L14.8911 111.772L11.3723 116.113L11.4689 116.305L17.0527 116.057ZM10.2582 98.2145L14.3677 97.3166L13.8006 94.7232L9.67491 95.6245L0.949684 91.1678L1.64716 94.3573L7.78459 97.4047L3.48245 102.75L4.17993 105.939L10.2582 98.2145ZM97.8867 14.4955L99.1701 10.4914L95.5312 1.36158L98.6418 2.35766L101.111 8.7583L106.827 4.97866L109.937 5.97474L101.704 11.2856L100.416 15.3055L97.8867 14.4955ZM122.337 12.0151L115.056 21.2897L117.132 22.9184L122.377 16.2381L123.699 28.0692L125.801 29.7183L133.083 20.4437L131.006 18.815L125.772 25.4823L124.44 13.6642L122.337 12.0151ZM132.748 37.3748C131.5 35.686 130.935 34.0803 131.054 32.5575C131.182 31.0283 132.042 29.6758 133.634 28.5002C135.218 27.3312 136.755 26.9137 138.246 27.2478C139.746 27.5753 141.143 28.6144 142.436 30.3651L144.201 32.7525C145.494 34.5032 146.077 36.1431 145.95 37.6724C145.831 39.1951 144.98 40.541 143.396 41.7101C141.804 42.8857 140.258 43.3097 138.758 42.9822C137.267 42.6481 135.891 41.6278 134.63 39.9213L132.748 37.3748ZM140.819 31.7846C140.094 30.8031 139.352 30.1689 138.593 29.882C137.834 29.595 137.017 29.6649 136.143 30.0916L142.612 38.8451C143.277 38.1355 143.584 37.3759 143.533 36.5665C143.481 35.757 143.093 34.8616 142.368 33.8801L140.819 31.7846ZM134.679 36.3798L136.198 38.4355C136.93 39.4258 137.672 40.06 138.424 40.3382C139.183 40.6251 140.004 40.552 140.887 40.1187L134.418 31.3652C133.744 32.0814 133.433 32.8442 133.484 33.6537C133.536 34.4631 133.934 35.3718 134.679 36.3798ZM151.282 43.1548L140.683 48.4918L141.451 50.5634L146.623 53.6406L144.704 59.3288L145.473 61.4004L156.991 58.5369L156.073 56.0634L147.655 58.1293L148.876 54.2121L154.598 52.0903L153.68 49.6168L147.973 51.7329L144.465 49.5339L152.2 45.6283L151.282 43.1548Z" fill="black"/>
                                    </svg>
                                    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <mask style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="40" height="40">
                                        <path d="M0 0H40V40H0V0Z" fill="white"/>
                                        </mask>
                                        <g>
                                        <path d="M11.668 6.66663V33.3333L33.3346 20L11.668 6.66663Z" stroke="#FF640D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </g>
                                    </svg>                                        
                                </span>
                            </a>
                            <img src="assets/images/video-img/video-img1.webp" alt="traning_video" class="h-100">
                        </div>
                    </div>
                </div>
            </div>
            <div class="overlay-video">
                <div class="videoWrapperExt">
                    <div class="videoWrapper">
                        <div class="close">
                            <svg class="close-button-icon-video" viewBox="0 0 24 24">
                                <path d="M5.5 5.5L18.5 18.5M18.5 5.5L5.5 18.5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </div>
                        <iframe id="player" width="853" height="480" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
        <!-- Traning-Video End -->

        <!-- Gallery Slider Start -->
                        <section class="gallery_slider_sec bg_black" id="gallery_slider_sec_home3">
                            <div class="gallery_slider_section sec_padding overflow_x_hidden">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="common_title_area gallery_slider_title text-center">
                                                <h5 class="satoshi_fontfamily fw_500 line_height_normal color_orange reveal custom_fade_top">Watch The Gallery</h5>
                                                <h3 class="pt-10 reveal custom_lightSpeedInLeft color_white">UNLIMITED TRAININGS ANYWHERE</h3>
                                                <h4 class="d-none">hidden</h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gallery_slider_area pt-60">
                                    <div class="container-fluid">
                                        <div class="gallery_slider_list lazy reveal custom_fade_right">
                                            <div class="gallery_slider_item">
                                                <div class="gallery_slider_img">
                                                    <img src="assets/images/gallery/gallery-1.webp" alt="gallery_slider_img">
                                                </div>
                                            </div>
                                            <div class="gallery_slider_item">
                                                <div class="gallery_slider_img">
                                                    <img src="assets/images/gallery/gallery-2.webp" alt="gallery_slider_img">
                                                </div>
                                            </div>
                                            <div class="gallery_slider_item">
                                                <div class="gallery_slider_img">
                                                    <img src="assets/images/gallery/gallery-3.webp" alt="gallery_slider_img">
                                                </div>
                                            </div>
                                            <div class="gallery_slider_item">
                                                <div class="gallery_slider_img">
                                                    <img src="assets/images/gallery/gallery-4.webp" alt="gallery_slider_img">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <!-- Gallery Slider End -->

        <!-- Contact-Us Page Start -->
        <section class="our_contactus_page_sec" id="our_contactus_page">
            <div class="container">
                <div class="contactus_page_area sec_padding">
                    <div class="row">
                        <div class="col-lg-6">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14526.800543972471!2d54.378487!3d24.4611869!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5e67bfac907a29%3A0x1a79b19062210edc!2sGym%2063%20fitness!5e0!3m2!1sen!2sin!4v1726134516437!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div> 
                        <div class="col-lg-6">
                            <div class="contactus_page_form_area">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="common_title_area contactus_page_form_title text-lg-start text-center">
                                            <h3 class="reveal custom_lightSpeedInLeft">CONTACT US</h3>
                                            
                                            <p class="satoshi_fontfamily fw_500 line_height_30 color_lightblack pt-20 pb-40" data-aos="fade-down">Your email address will not be published. Required fields are marked*</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="get_touch_form_area">
                                    <form>
                                        <div class="get_touch_form">
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="get_touch_box reveal custom_zoom_in active">
                                                        <input type="text" class="form-control satoshi_fontfamily fw_500 line_height_24" placeholder="Your Name*" required="">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="get_touch_box reveal custom_zoom_in active">
                                                        <input type="email" class="form-control satoshi_fontfamily fw_500 line_height_24" placeholder="Your Email Address*" required="">
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="get_touch_box reveal custom_zoom_in active">
                                                        <input type="text" class="form-control satoshi_fontfamily fw_500 line_height_24" placeholder="Subject*" required="">
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="get_touch_box reveal custom_zoom_in active">
                                                        <textarea class="form-control satoshi_fontfamily fw_500 line_height_24" placeholder="Drop us a few lines here..."></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="get_touch_box">
                                                        <button type="submit" class="orange_btn black_btn border-0 p-0 bg_transparent reveal custom_fade_buttom active">
                                                            <span class="orenge_text whiteglow_btn" data-hover="Submit Now">
                                                                Submit Now
                                                            </span>
                                                            <span class="orenge_icon whiteglow_btn">
                                                                <img src="assets/images/svgs/common_button_arrow1.webp" alt="common_button_arrow">
                                                            </span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
        <!-- Contact-Us Page end -->

        

        

        <?php include_once("assets/includes/footer.php");?>
        <!-- Scroll-Top Start -->
        <div class="scrolltop_area orangeglow">
            <button id="scroll-top-btn">
                <span class="scroll-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <mask style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24">
                        <path d="M0 0H24V24H0V0Z" fill="white"/>
                        </mask>
                        <g>
                        <path d="M7 11L12 6L17 11" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M7 17L12 12L17 17" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </g>
                    </svg>                        
                </span>
                <span id="scroll-percentage"></span>
            </button>    
        </div>
        <!-- Scroll-Top End --> 

       

    </div>
<?php include_once("assets/includes/scripts.php");?>
   
</body>
</html>